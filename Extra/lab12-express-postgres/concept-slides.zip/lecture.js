(() => {
  'use strict';

  const slides = Array.isArray(window.LAB12_SLIDES) ? window.LAB12_SLIDES : [];
  const mentorCredit = 'Dr. Pisit Praiwattana, your mentor in 2026';
  const requestedSlide = new URLSearchParams(window.location.search).get('slide');
  let current = Math.max(0, slides.findIndex(slide => slide.id === requestedSlide));
  let previousFocus;
  let previousOverflow = '';
  const overlay = document.createElement('div');
  overlay.className = 'lecture-overlay';
  overlay.hidden = true;
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', 'Compose concept presentation');
  overlay.innerHTML = '<div class="slide-scroll"><article class="slide-content"></article></div>' +
    '<div class="slide-mentor" aria-label="Mentor">' + mentorCredit + '</div>' +
    '<div class="slide-controls"><button type="button" id="slide-prev">← Previous</button>' +
    '<span id="slide-count" aria-live="polite" aria-atomic="true"></span>' +
    '<button type="button" id="slide-next">Next →</button>' +
    '<label class="slide-jump-label" for="slide-jump">Go to slide</label>' +
    '<select id="slide-jump" aria-label="Go to slide"></select>' +
    '<button type="button" id="slide-close">Exit · Esc</button></div>';
  document.body.append(overlay);

  const content = overlay.querySelector('.slide-content');
  const scrollArea = overlay.querySelector('.slide-scroll');
  const prev = overlay.querySelector('#slide-prev');
  const next = overlay.querySelector('#slide-next');
  const jump = overlay.querySelector('#slide-jump');
  const closeButton = overlay.querySelector('#slide-close');

  const textSizeKey = 'lab12-reader-text-percent';
  let textPercent = 125;
  try {
    const saved = Number(localStorage.getItem(textSizeKey));
    if (Number.isFinite(saved) && saved >= 100 && saved <= 200) textPercent = Math.round(saved);
  } catch (_) { /* Reading controls also work when browser storage is unavailable. */ }
  const textSizeControls = [];

  function makeTextSizeControls(context) {
    const group = node('div', 'text-size-controls');
    group.setAttribute('role', 'group');
    group.setAttribute('aria-label', `${context} text size`);
    const decrease = node('button', 'text-size-step', '−−');
    decrease.type = 'button';
    decrease.setAttribute('aria-label', `Decrease ${context.toLowerCase()} text size`);
    decrease.title = 'Smaller text';
    decrease.addEventListener('click', () => setTextSize(textPercent - 10));
    group.append(decrease);
    const presets = [100, 125, 150, 175].map((percent, index) => {
      const button = node('button', `text-size-preset text-size-preset-${index + 1}`, 'A');
      button.type = 'button';
      button.setAttribute('aria-label', `${context} text size ${percent} percent`);
      button.title = `${percent}% text size`;
      button.addEventListener('click', () => setTextSize(percent));
      group.append(button);
      return {button, percent};
    });
    const increase = node('button', 'text-size-step', '++');
    increase.type = 'button';
    increase.setAttribute('aria-label', `Increase ${context.toLowerCase()} text size`);
    increase.title = 'Larger text';
    increase.addEventListener('click', () => setTextSize(textPercent + 10));
    const value = node('span', 'text-size-value');
    value.setAttribute('aria-live', 'polite');
    value.setAttribute('aria-atomic', 'true');
    group.append(increase, value);
    textSizeControls.push({decrease, increase, presets, value});
    return group;
  }

  function setTextSize(percent, remember = true) {
    textPercent = Math.max(100, Math.min(200, Math.round(percent)));
    document.documentElement.style.setProperty('--reader-scale', String(textPercent / 100));
    overlay.dataset.largeText = String(textPercent >= 150);
    textSizeControls.forEach(({decrease, increase, presets, value}) => {
      decrease.disabled = textPercent === 100;
      increase.disabled = textPercent === 200;
      presets.forEach(preset => preset.button.setAttribute('aria-pressed', String(preset.percent === textPercent)));
      value.textContent = `${textPercent}%`;
    });
    if (remember) {
      try { localStorage.setItem(textSizeKey, String(textPercent)); } catch (_) { /* Optional persistence. */ }
    }
  }

  const pageSizeControls = makeTextSizeControls('Page');
  const pageHeader = document.querySelector('body > header');
  const landingActions = document.querySelector('.lecture-actions');
  if (pageHeader) {
    pageHeader.insertBefore(pageSizeControls, pageHeader.lastElementChild);
    const updateHeaderHeight = () => document.documentElement.style.setProperty('--reader-header-height', `${Math.ceil(pageHeader.getBoundingClientRect().height)}px`);
    updateHeaderHeight();
    if (typeof ResizeObserver === 'function') new ResizeObserver(updateHeaderHeight).observe(pageHeader);
    else window.addEventListener('resize', updateHeaderHeight);
  } else if (landingActions) landingActions.before(pageSizeControls);
  overlay.querySelector('.slide-controls').insertBefore(makeTextSizeControls('Slide'), closeButton);
  if (window.Lab12I18n) overlay.querySelector('.slide-controls').insertBefore(window.Lab12I18n.makeControls(), closeButton);
  setTextSize(textPercent, false);

  function node(tag, className, value) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (value !== undefined) element.textContent = value;
    return element;
  }

  function makeCode(source, interactive) {
    const wrapper = node('div', 'slide-code');
    const bar = node('div', 'slide-codebar');
    bar.append(node('span', '', source.language || 'Code'));
    if (interactive) {
      const button = node('button', 'slide-copy', 'Copy code');
      button.type = 'button';
      button.setAttribute('aria-label', `Copy ${source.language || 'slide'} code`);
      button.addEventListener('click', async () => {
        let success = false;
        try {
          await navigator.clipboard.writeText(String(source.text || ''));
          success = true;
        } catch (_) {
          const input = node('textarea', 'slide-copy-fallback', source.text || '');
          input.setAttribute('aria-label', 'Code to copy');
          input.readOnly = true;
          wrapper.append(input);
          input.focus();
          input.select();
          try { success = document.execCommand('copy'); } catch (_) { /* Manual selection stays available. */ }
          input.remove();
          button.focus();
        }
        button.textContent = success ? 'Copied!' : 'Select code to copy';
        if (!success) {
          const selection = window.getSelection();
          const range = document.createRange();
          range.selectNodeContents(pre);
          selection.removeAllRanges();
          selection.addRange(range);
        }
        window.setTimeout(() => { button.textContent = 'Copy code'; }, 2000);
      });
      bar.append(button);
    }
    const pre = node('pre');
    pre.tabIndex = 0;
    pre.setAttribute('aria-label', 'Code; scroll horizontally if needed');
    pre.append(node('code', '', source.text || ''));
    wrapper.append(bar, pre);
    return wrapper;
  }

  function makeComparison(comparison) {
    const wrapper = node('div', 'slide-table-wrap');
    wrapper.tabIndex = 0;
    wrapper.setAttribute('aria-label', 'Comparison table; scroll horizontally if needed');
    const table = node('table', 'slide-table');
    if (Array.isArray(comparison.headers) && comparison.headers.length) {
      const thead = node('thead');
      const row = node('tr');
      comparison.headers.forEach(header => {
        const cell = node('th', '', header);
        cell.scope = 'col';
        row.append(cell);
      });
      thead.append(row);
      table.append(thead);
    }
    const tbody = node('tbody');
    (comparison.rows || []).forEach(values => {
      const row = node('tr');
      values.forEach((value, index) => {
        const cell = node(index === 0 ? 'th' : 'td', '', value);
        if (index === 0) cell.scope = 'row';
        row.append(cell);
      });
      tbody.append(row);
    });
    table.append(tbody);
    wrapper.append(table);
    return wrapper;
  }

  function makeOutput(source, interactive) {
    const wrapper = node('div', 'slide-output');
    wrapper.setAttribute('role', 'group');
    const label = source.label || 'Expected output';
    wrapper.setAttribute('aria-label', source.language ? `${label}: ${source.language}` : label);
    const bar = node('div', 'slide-outputbar');
    bar.append(node('span', '', label));
    if (source.language) bar.append(node('span', 'slide-output-format', source.language));
    const pre = node('pre');
    if (interactive) {
      pre.tabIndex = 0;
      pre.setAttribute('aria-label', `${label}; scroll horizontally if needed`);
    }
    pre.append(node('samp', '', source.text || ''));
    wrapper.append(bar, pre);
    return wrapper;
  }

  function populate(target, slide, interactive) {
    const workedExample = slide.kicker === 'WORKED EXAMPLE';
    slide = window.Lab12I18n?.getSlide(slide) || slide;
    target.replaceChildren();
    target.classList.toggle('has-code', Boolean(slide.code));
    target.classList.toggle('has-output', Boolean(slide.output));
    target.classList.toggle('has-table', Boolean(slide.comparison));
    target.classList.toggle('has-diagram', Boolean(slide.diagram));
    target.classList.toggle('is-worked-example', workedExample);
    target.append(node('div', 'slide-kicker', slide.kicker || 'Docker concepts'));
    const heading = node('h1', 'slide-title', slide.title || 'Docker concepts');
    if (interactive) heading.tabIndex = -1;
    target.append(heading);
    if (slide.summary) target.append(node('p', 'slide-summary', slide.summary));

    const grid = node('div', 'slide-grid');
    const body = node('div', 'slide-explanation');
    if (Array.isArray(slide.body) && slide.body.length) {
      const list = node('ul', 'slide-points');
      slide.body.forEach(value => list.append(node('li', '', value)));
      body.append(list);
    }
    grid.append(body);
    if (slide.code || slide.output || slide.comparison || slide.diagram) {
      const example = node('div', 'slide-example');
      if (slide.code) example.append(makeCode(slide.code, interactive));
      if (slide.output) example.append(makeOutput(slide.output, interactive));
      if (slide.comparison) example.append(makeComparison(slide.comparison));
      if (slide.diagram) {
        const diagram = node('pre', 'slide-diagram');
        diagram.setAttribute('aria-label', 'Architecture diagram');
        diagram.tabIndex = 0;
        diagram.textContent = slide.diagram;
        example.append(diagram);
      }
      grid.append(example);
    }
    target.append(grid);

    if (Array.isArray(slide.refs) && slide.refs.length) {
      const references = node('div', 'slide-references');
      references.append(node('span', '', 'References'));
      const list = node('ul');
      slide.refs.forEach(reference => {
        try {
          const url = new URL(reference.url);
          if (!['https:', 'http:'].includes(url.protocol)) return;
          const item = node('li');
          const link = node('a', '', reference.title || url.hostname);
          link.href = url.href;
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          item.append(link);
          list.append(item);
        } catch (_) { /* Ignore malformed reference URLs. */ }
      });
      references.append(list);
      target.append(references);
    }
    if (!interactive) target.append(node('div', 'slide-mentor-footer', mentorCredit));
  }

  slides.forEach((slide, index) => {
    const option = node('option', '', `${index + 1}. ${(window.Lab12I18n?.getSlide(slide) || slide).title}`);
    option.value = String(index);
    jump.append(option);
  });

  function render(focusHeading = false) {
    if (!slides.length) {
      populate(content, {
        title: 'The slide content could not be loaded',
        summary: 'Keep lecture-data.js beside lecture.js and reopen this page.',
        body: [], refs: []
      }, true);
      prev.disabled = true;
      next.disabled = true;
      jump.disabled = true;
      overlay.querySelector('#slide-count').textContent = 'No slides loaded';
      if (focusHeading) content.querySelector('h1').focus({ preventScroll: true });
      return;
    }
    populate(content, slides[current], true);
    overlay.querySelector('#slide-count').textContent = `${current + 1} / ${slides.length}`;
    jump.value = String(current);
    prev.disabled = current === 0;
    next.disabled = current === slides.length - 1;
    scrollArea.scrollTop = 0;
    if (focusHeading) content.querySelector('h1').focus({ preventScroll: true });
  }

  function goTo(index, focusHeading = false) {
    const destination = Math.max(0, Math.min(slides.length - 1, index));
    if (destination === current || !slides.length) return;
    current = destination;
    render(focusHeading);
    if ((document.activeElement === prev && prev.disabled) || (document.activeElement === next && next.disabled)) {
      content.querySelector('h1').focus({ preventScroll: true });
    }
  }

  function open() {
    previousFocus = document.activeElement;
    previousOverflow = document.body.style.overflow;
    overlay.hidden = false;
    document.body.style.overflow = 'hidden';
    render(true);
  }

  function close() {
    overlay.hidden = true;
    document.body.style.overflow = previousOverflow;
    if (previousFocus && previousFocus.isConnected) previousFocus.focus();
  }

  document.getElementById('present')?.addEventListener('click', open);
  if (window.location.hash === '#present') open();
  prev.addEventListener('click', () => goTo(current - 1));
  next.addEventListener('click', () => goTo(current + 1));
  jump.addEventListener('change', () => goTo(Number(jump.value)));
  closeButton.addEventListener('click', close);
  document.addEventListener('lab12-language-change', () => {
    slides.forEach((slide,index) => { jump.options[index].textContent = `${index + 1}. ${(window.Lab12I18n?.getSlide(slide) || slide).title}`; });
    document.querySelector('.lecture-print-deck')?.remove();
    if (!overlay.hidden) render();
  });

  function focusableElements() {
    return [...overlay.querySelectorAll('button:not(:disabled), select:not(:disabled), a[href], textarea, [tabindex="0"]')]
      .filter(element => !element.hidden && element.getClientRects().length);
  }

  document.addEventListener('keydown', event => {
    if (overlay.hidden) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      close();
      return;
    }
    if (event.key === 'Tab') {
      const controls = focusableElements();
      if (!controls.length) return;
      const index = controls.indexOf(document.activeElement);
      const destination = index < 0 ? (event.shiftKey ? controls.length - 1 : 0) :
        (index + (event.shiftKey ? -1 : 1) + controls.length) % controls.length;
      event.preventDefault();
      controls[destination].focus();
      return;
    }
    const target = event.target;
    if (event.altKey || event.ctrlKey || event.metaKey || target.closest('input, textarea, select, [contenteditable="true"]')) return;
    if (event.key === ' ' && target.closest('button, a')) return;
    if (target.closest('.slide-diagram, .slide-table-wrap, .slide-output pre, .slide-code pre') && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const actions = {
      ArrowRight: () => goTo(current + 1, true),
      ' ': () => goTo(current + 1, true),
      PageDown: () => goTo(current + 1, true),
      ArrowLeft: () => goTo(current - 1, true),
      PageUp: () => goTo(current - 1, true),
      Home: () => goTo(0, true),
      End: () => goTo(slides.length - 1, true)
    };
    if (actions[event.key]) {
      event.preventDefault();
      actions[event.key]();
    }
  });

  document.addEventListener('focusin', event => {
    if (!overlay.hidden && !overlay.contains(event.target)) content.querySelector('h1')?.focus({ preventScroll: true });
  });

  document.getElementById('print-slides')?.addEventListener('click', () => {
    if (!slides.length) return;
    let deck = document.querySelector('.lecture-print-deck');
    if (!deck) {
      deck = node('div', 'lecture-print-deck');
      slides.forEach((slide, index) => {
        const page = node('article', 'lecture-print-slide slide-content');
        populate(page, slide, false);
        page.append(node('div', 'lecture-print-number', `${index + 1} / ${slides.length}`));
        deck.append(page);
      });
      document.body.append(deck);
    }
    document.body.classList.add('lecture-printing');
    const restore = () => {
      document.body.classList.remove('lecture-printing');
      window.removeEventListener('afterprint', restore);
    };
    window.addEventListener('afterprint', restore);
    window.Lab12I18n?.apply();
    window.print();
  });
})();
