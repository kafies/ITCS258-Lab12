(() => {
  'use strict';
  const data=window.LAB12_I18N_DATA || {guide:{},ui:{},slides:{}};
  const storageKey='lab12-language';
  let language='en';
  try { const saved=localStorage.getItem(storageKey); if(['en','th'].includes(saved)) language=saved; } catch (_) {}
  const requested=new URLSearchParams(window.location.search).get('lang');
  if(['en','th'].includes(requested)) {
    language=requested;
    try { localStorage.setItem(storageKey,language); } catch (_) {}
  }
  const sources=new WeakMap();
  const attributes=new WeakMap();
  const controls=[];
  const englishTitle=document.title;
  const excluded='pre,code,kbd,script,style,textarea,[data-no-translate],.language-switcher';

  function thai(text) {
    if(Object.hasOwn(data.ui,text)) return data.ui[text];
    if(Object.hasOwn(data.guide,text)) return data.guide[text];
    let match=text.match(/^(\d+) \/ (\d+) checkpoints$/);
    if(match) return `${match[1]} / ${match[2]} จุดตรวจสอบ`;
    match=text.match(/^(Page|Slide) text size (\d+) percent$/);
    if(match) return `ขนาดตัวอักษร${match[1]==='Page'?'หน้าเว็บ':'สไลด์'} ${match[2]} เปอร์เซ็นต์`;
    match=text.match(/^(Decrease|Increase) (page|slide) text size$/);
    if(match) return `${match[1]==='Decrease'?'ลด':'เพิ่ม'}ขนาดตัวอักษร${match[2]==='page'?'หน้าเว็บ':'สไลด์'}`;
    match=text.match(/^(\d+)% text size$/);
    if(match) return `ขนาดตัวอักษร ${match[1]}%`;
    match=text.match(/^Copy (.+) code$/);
    if(match) return `คัดลอกโค้ด ${thai(match[1])}`;
    match=text.match(/^Expected output: (.+)$/);
    if(match) return `ผลลัพธ์ที่คาดว่าจะได้: ${thai(match[1])}`;
    return text;
  }

  function translated(source) {
    if(language==='en') return source;
    const core=source.trim();
    return core ? source.replace(core,()=>thai(core)) : source;
  }

  function applyTranslations() {
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    let node;
    while((node=walker.nextNode())) {
      if(node.parentElement?.closest(excluded)) continue;
      const before=sources.get(node);
      const source=before && node.nodeValue===before.rendered ? before.source : node.nodeValue;
      const rendered=translated(source);
      if(node.nodeValue!==rendered) node.nodeValue=rendered;
      sources.set(node,{source,rendered});
    }
    document.body.querySelectorAll('[aria-label],[alt],[title]').forEach(element=>{
      if(element.closest('script,style,[data-no-translate],.language-switcher')) return;
      const saved=attributes.get(element)||{};
      for(const key of ['aria-label','alt','title']) {
        if(!element.hasAttribute(key)) continue;
        const current=element.getAttribute(key);
        const source=saved[key] && current===saved[key].rendered ? saved[key].source : current;
        const rendered=translated(source);
        if(current!==rendered) element.setAttribute(key,rendered);
        saved[key]={source,rendered};
      }
      attributes.set(element,saved);
    });
  }

  function makeControls() {
    const group=document.createElement('div');
    group.className='language-switcher';
    group.setAttribute('role','group');
    group.setAttribute('aria-label','Language / ภาษา');
    for(const [code,label] of [['en','EN'],['th','ไทย']]) {
      const button=document.createElement('button');
      button.type='button'; button.textContent=label; button.lang=code;
      button.setAttribute('aria-label',code==='en'?'English':'ภาษาไทย');
      button.addEventListener('click',()=>setLanguage(code));
      group.append(button); controls.push({button,code});
    }
    updateControls();
    return group;
  }

  function updateControls() {
    controls.forEach(({button,code})=>button.setAttribute('aria-pressed',String(code===language)));
  }

  function setLanguage(next,remember=true) {
    if(!['en','th'].includes(next)) return;
    language=next;
    document.documentElement.lang=language;
    document.title=language==='th'?thai(englishTitle):englishTitle;
    if(remember) {
      try { localStorage.setItem(storageKey,language); } catch (_) {}
      try {
        const url=new URL(window.location.href);
        if(['http:','https:'].includes(url.protocol)) {
          url.searchParams.set('lang',language);
          window.history.replaceState(window.history.state,'',url);
        }
      } catch (_) {}
    }
    updateControls();
    document.dispatchEvent(new CustomEvent('lab12-language-change',{detail:{language}}));
    applyTranslations();
  }

  function getSlide(slide) {
    if(language!=='th') return slide;
    const th=data.slides[slide.id];
    if(!th) return slide;
    return {...slide,...th,id:slide.id,refs:slide.refs,
      code:slide.code?{...slide.code,language:th.code?.language||slide.code.language}:undefined,
      output:slide.output?{...slide.output,
        language:slide.output.language?(th.output?.language||slide.output.language):undefined,
        label:slide.output.label?(th.output?.label||slide.output.label):undefined,
        text:slide.output.text}:undefined,
      diagram:slide.diagram};
  }

  window.Lab12I18n={get language(){return language;},setLanguage,makeControls,getSlide,
    text:source=>language==='th'?thai(source):source,apply:applyTranslations};
  const header=document.querySelector('body>header');
  const actions=document.querySelector('.lecture-actions');
  if(header) header.insertBefore(makeControls(),header.lastElementChild);
  else if(actions) actions.before(makeControls());
  let scheduled=false;
  new MutationObserver(()=>{
    if(scheduled) return;
    scheduled=true;
    queueMicrotask(()=>{scheduled=false;applyTranslations();});
  }).observe(document.body,{subtree:true,childList:true,characterData:true});
  setLanguage(language,false);
})();
